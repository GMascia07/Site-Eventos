package br.senai.service;

import br.senai.model.Cliente;
import br.senai.repository.ClienteRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class ClienteServiceImpl implements ClienteService {
    @Autowired
    ClienteRepository clienteRepository;

    public ClienteServiceImpl() {
    }

    public List<Cliente> findAll() {
        return this.clienteRepository.findAll(Sort.by(new String[]{"nome"}));
    }

    public Cliente findById(Long id) {
        Optional listCliente = this.clienteRepository.findById(id);
        return !listCliente.isEmpty() ? (Cliente)listCliente.get() : new Cliente();
    }

    public Cliente findByNome(String nome) {
        return this.clienteRepository.findByNome(nome);
    }

    public Cliente save(Cliente cliente) {
        try {
            return (Cliente)this.clienteRepository.save(cliente);
        } catch (Exception var3) {
            throw var3;
        }
    }
}
